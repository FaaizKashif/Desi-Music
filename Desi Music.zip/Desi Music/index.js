const { Client, GatewayIntentBits, REST, Routes, SlashCommandBuilder } = require("discord.js");
const { DisTube } = require("distube");
const { config } = require("dotenv");

config();

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildVoiceStates,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent
  ],
});

const distube = new DisTube(client, {
  leaveOnFinish: false,
  leaveOnStop: false,
  emitNewSongOnly: true,
  youtubeDL: true
});

// 🎵 Slash commands
const commands = [
  new SlashCommandBuilder().setName("play").setDescription("Play a song").addStringOption(option =>
    option.setName("query").setDescription("Song name or link").setRequired(true)
  ),
  new SlashCommandBuilder().setName("skip").setDescription("Skip the current song"),
  new SlashCommandBuilder().setName("stop").setDescription("Stop the music")
].map(cmd => cmd.toJSON());

// Register commands
const rest = new REST({ version: "10" }).setToken(process.env.DISCORD_TOKEN);

(async () => {
  try {
    console.log("Started refreshing slash commands...");
    await rest.put(
      Routes.applicationCommands(process.env.CLIENT_ID),
      { body: commands }
    );
    console.log("Slash commands registered ✅");
  } catch (err) {
    console.error(err);
  }
})();

// 🎶 Events
client.on("ready", () => {
  console.log(`✅ Desi Music Bot is online as ${client.user.tag}`);
});

client.on("interactionCreate", async interaction => {
  if (!interaction.isChatInputCommand()) return;

  const voiceChannel = interaction.member?.voice.channel;
  if (!voiceChannel) return interaction.reply("⚠️ Join a voice channel first!");

  try {
    if (interaction.commandName === "play") {
      const query = interaction.options.getString("query");
      distube.play(voiceChannel, query, { textChannel: interaction.channel, member: interaction.member });
      await interaction.reply(`🎵 Playing: \`${query}\``);
    } else if (interaction.commandName === "skip") {
      distube.skip(interaction);
      await interaction.reply("⏭ Skipped!");
    } else if (interaction.commandName === "stop") {
      distube.stop(interaction);
      await interaction.reply("⏹ Stopped!");
    }
  } catch (err) {
    console.error(err);
    interaction.reply("❌ Error: " + err.message);
  }
});

distube.on("playSong", (queue, song) => {
  queue.textChannel.send(`🎶 Now playing: **${song.name}**`);
});

client.login(process.env.DISCORD_TOKEN);
